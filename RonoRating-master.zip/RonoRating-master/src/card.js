function cardCommand(fs, msg, ctx, sharp, canvas, client, iniciator, interaction) {
  {
    if (fs.existsSync('./data/UserData/' + iniciator))
   {




        const args = msg.slice(`/био`).split(/ +/);

            let preview = false
    if (msg.toLowerCase().startsWith('/preview')) { preview = true}

    
    if (msg.toLowerCase().startsWith('/card')) { preview = false}
    if (args.length >= 2)
    {
      pingedUser = args[1]
      pingedUser = pingedUser.replace("<@",'')
      pingedUser = pingedUser.replace("!",'')
      pingedUser = pingedUser.replace(">",'')
    }
    if (args.length >= 2)
    {
      pingedUser = args[1]
    }
    if ((args.length >= 2) && (!args[1].includes('<@')))
    {
      pingedUser = '<@' + args[1] + '>'
      console.log(pingedUser)
    }
    if (args.length == 1)
    {
      console.log('прошло')
      pingedUser = '<@' + iniciator +">"
    }

    if (args.length > 2)
    {    
      interaction.channel.send('Слишком много аргументов! После команды Вам следует написать лишь один аргумент - упомянание пользователя, его id или вообще не использовать аргументы.\nНе смотря на это, мы всё равно попробуем распознать упоминание')
    }


   if (pingedUser.includes('<@'))
   {
     pingedUser = pingedUser.replace("<@",'')
     pingedUser = pingedUser.replace("!",'')
     pingedUser = pingedUser.replace(">",'')
   }else {}

   if (fs.existsSync('./data/UserData/' + pingedUser))
   { }else{pingedUser = iniciator}
    client.users.fetch(pingedUser).then(User => 
  {

   interaction.reply('Загружаем...')


//АЧВИКИ
ctx.font = '30px "ArialRound"'

    ctx.strokeStyle = 'white';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'black';


    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.textAlign = 'right'

let fontsize = 70

//Актив макс уровень
             let lastLvl = '0'
             try{lastLvl  = fs.readFileSync('./data/UserData/' + pingedUser + '/tasks/activity', "utf8")}catch(err){}

          const currentXP = Math.floor(fs.readFileSync('./data/UserData/' + pingedUser + '/integers/exp', "utf8"))
          const levelNeed = fs.readFileSync('./data/UserData/' + pingedUser + '/integers/lvl', "utf8");
           NeededXP = 8
           CycleNum = 0
           active = true
           while (active == true)
           {
             if (NeededXP < 460) { NeededXP = NeededXP * 1.12 }else{NeededXP = 500; active == false } //break;
             CycleNum = CycleNum + 1
             if (CycleNum > levelNeed) { active = false }
           }


  NeededXP = Math.floor(NeededXP)

        // interaction.channel.send(currentXP.toString() + '/' + NeededXP.toString())
        ctx.fillText(NeededXP, 458, 400)
        ctx.strokeText(NeededXP, 458, 400)

ctx.textAlign = 'left'
        ctx.fillText(currentXP, 175, 400)
        ctx.strokeText(currentXP, 175, 400)

ctx.textAlign = 'center'
        ctx.fillText(lastLvl + ' уровень', 323, 400)



        ctx.font = '47px "ArialRound"'

    ctx.strokeStyle = 'white';
ctx.textAlign = 'left'
        ctx.fillText('Активность', 185, 330)
        ctx.strokeText('Активность', 185, 330)

        let activeImg = './Images/Blank.png'
        if (-1<lastLvl<9999)
        {
          activeImg = './tasks/activity/basic.png'
        }




        let actwidth = Math.floor(270 * (currentXP / NeededXP) + 1)
             if (actwidth >= 270) {actwidth = 269}
      sharp('./tasks/fullBar.png')
 
        .extract({ left: 0, top: 0, width: actwidth, height: 30 })
      .toBuffer()
            .then(function(outputBufferAct) {

//Актив дни подряд
let lastActiveLvl  = 0
let lastActive = '0 0 0'
let InputMassive = ['0', '0', '0']
try{
lastActiveLvl = Number(fs.readFileSync('./data/UserData/' + pingedUser + '/tasks/lastActve', "utf8"));
lastActive = fs.readFileSync('./data/UserData/' + pingedUser + '/badges/lastActve', "utf8");
InputMassive = lastActive.split(' ', 3);
}catch(err){
  lastActiveLvl = 0
  InputMassive = ['0','0','0']
}
let activeDays = [0,2,4,7,10,14,18,21,25,31,45,60,90]

ctx.font = '30px "ArialRound"'
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'black';
    ctx.textAlign = 'right'

let fontsize = 70


        ctx.fillText(activeDays[lastActiveLvl + 1], 962, 400)
        ctx.strokeText(activeDays[lastActiveLvl + 1], 962, 400)

ctx.textAlign = 'left'
        ctx.fillText(InputMassive[2], 689, 400)
        ctx.strokeText(InputMassive[2], 689, 400)

ctx.textAlign = 'center'
        ctx.fillText(lastActiveLvl + ' уровень', 827, 400)


        ctx.font = '33px "ArialRound"'

    ctx.strokeStyle = 'white';
ctx.textAlign = 'left'
        ctx.fillText('Повседневность', 689, 320)
        ctx.strokeText('Повседневность', 689, 320)

sharp('./tasks/lastActiveBar.png')
        .extract({ left: 0, top: 0, width: Math.floor(InputMassive[2] / activeDays[lastActiveLvl + 1] * 269 + 1 ), height: 30 })
      .toBuffer()
            .then(function(outputBufferAct1) {



///////////////ГС АКТИВ
let currentLvl = fs.readFileSync('./data/UserData/' + pingedUser + '/tasks/voice')
        let userActivity = fs.readFileSync('./data/UserData/' + pingedUser + '/integers/voice')

        
let lvlArray = [0.5,1,1.5,2,3,4,5,10,15,20,25,30,45,50,75,90,120,150,180,220,280,320,390,460,500,600,750,800,900,1000]

      let rewards = [50,100,300,400,800,1200,3000, 7000, 7000, 8500, 9000, 9000,9000,10000,11000,15000,16000,17000,18000,19000,20000,25000,25000,25000,25000,25000,25000,40000,40000,250000]


      ctx.font = '30px "ArialRound"'
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'black';
    ctx.textAlign = 'right'

let fontsize = 70
if (currentLvl > 29) { currentLvl = 29 }

        ctx.fillText(lvlArray[currentLvl], 458, 587)
        ctx.strokeText(lvlArray[currentLvl], 458, 587)

ctx.textAlign = 'left'
        ctx.fillText((userActivity/60).toFixed(1), 175, 587)
        ctx.strokeText((userActivity/60).toFixed(1), 175, 587)

ctx.textAlign = 'center'
        ctx.fillText(currentLvl + ' уровень', 323, 587)


        ctx.font = '33px "ArialRound"'



console.log('SECRET NUM: ' + Math.floor(269*((userActivity/60).toFixed(1))/lvlArray[currentLvl]+1))

    ctx.strokeStyle = 'white';
ctx.textAlign = 'left'
        ctx.fillText('Голосовой актив', 185, 507)
        ctx.strokeText('Голосовой актив', 185, 507)
        
        let vwidth = Math.floor(269*((userActivity/60).toFixed(1))/lvlArray[currentLvl]+1)

if ((vwidth >= 270) || (vwidth<1)) {vwidth = 269}


sharp('./tasks/voiceBar.png')


      .extract({ left: 0, top: 0, width: vwidth, height: 30 })
      .toBuffer()
            .then(function(outputBufferAct2) {






///////////////АКТИВ ГЛОБАЛ
      ctx.font = '20px "ArialRound"'
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'black';
    ctx.textAlign = 'left'

let fontsize = 45


let grandPath = './Images/Blank.png'
let barSize = 1

if (fs.existsSync('./data/UserData/' + pingedUser + '/DATATRANSFERCONFIRMATION'))
{
  let currentGlobalLvl = fs.readFileSync('./data/UserData/' + pingedUser + '/tasks/global')
  let currentGlobalExp = fs.readFileSync('./data/UserData/' + pingedUser + '/integers/grandXp')
  grandPath = './Images/grandbar.png'
  barSize = 
  ctx.fillText(Math.floor((Number(currentGlobalExp)).toString()), 132,255)

  let neededExp = 12
  let active1 = true
  let counterGlobal = 0
  let globalMoney = 25
  while (active1 == true)
  {
    neededExp = neededExp * 1.2
    counterGlobal = Number(counterGlobal) + 1
    if (counterGlobal >= Number(currentGlobalLvl)+1)
    {
      active1 = false
    }
// console.log(counterGlobal)
  }

  if (neededExp > 450) { neededExp = 450 }
  
  console.log('NEEDED / CURRENT ' + neededExp + '/' + currentGlobalExp)
barSize = currentGlobalExp / neededExp

console.log('bar1' + barSize)


}
barSize = Math.floor(520 * barSize)
console.log('ЙО!' + barSize)
if ((barSize >519) || (barSize < 1)) { barSize = 519 }
console.log('bar1' + barSize)
sharp(grandPath)


      .extract({ left: 0, top: 0, width: barSize, height: 7 })
      .toBuffer()
            .then(function(grandBuffer) {









    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.fillStyle = 'black';

ctx.font = '50px "Main"'
    ctx.textAlign = 'left'

fontsize = 70
let nameLength = User.tag.length
var request = require('request').defaults({ encoding: null });
 request.get(User.displayAvatarURL({ format: "png"}, {size: 300}), function (err, res, body) {


 



let Badge = fs.readFileSync('./data/UserData/' + pingedUser + '/config/badge', "utf8");
let badgePath = './Badges/' + Badge + '.png'

let Badge2 = fs.readFileSync('./data/UserData/' + pingedUser + '/config/badge2', "utf8");
let badge2Path = './Badges2/' + Badge2 + '.png'

  console.log('Адоптируем...')
  fontsize = 70 - (nameLength/3)*4
console.log('Адоптация:' + fontsize)

//Юзер
let Money = fs.readFileSync('./data/UserData/' + pingedUser + '/integers/money', "utf8");

let Level = '0'

if (fs.existsSync('./data/UserData/' + pingedUser + '/tasks/global'))
{
  Level = fs.readFileSync('./data/UserData/' + pingedUser + '/tasks/global', "utf8");
}
let Themes = fs.readdirSync('./data/UserData/' + pingedUser + '/themes', "utf8");



ctx.font = fontsize + 'px "Main"'
ctx.fillText(User.tag, 245, 110)
console.log('Тег: ' + User.tag)

ctx.font = '40px "ArialRound"'
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 1;
    ctx.fillStyle = 'black';
    ctx.textAlign = 'left'




let outputMoney = Money.toString()
Money = Math.floor(Money)


if (Money.toString().length > 3) {
outputMoney = (Math.floor(Money/10/10)/10).toString() + 'k'
}

if (Money.toString().length > 6) {
outputMoney = (Math.floor(Money/1000/10)/100).toString() + 'M'
}









ctx.fillText(outputMoney, 275, 168)
console.log('ДЕНЬГИ ВНЕСЕНЫ ' + outputMoney)
console.log('Мани: ' + outputMoney)
ctx.fillText(Level, 275, 218)
console.log('Мани: ' + Level)
console.log('VVV AMOUNT VVV')
ctx.font = '85px "ArialRound"'
ctx.textAlign = 'right'
console.log(Themes)
ctx.fillText(Themes.length , 580, 208)
console.log('Мани: ' + Level)

// let out = fs.createWriteStream(pingedUser + 'temp.png')
canvas.toBuffer((err, out) => { console.log('The PNG file was created.') 




let theme = fs.readFileSync('./data/UserData/' + pingedUser + '/config/theme', "utf8");




if (preview == true) {
  let fullarray = fs.readdirSync('Background')
  console.log('FULLARRAY: ' + fullarray)
  if (args[1] != undefined) {
  if (fullarray.includes(args[1].toLowerCase()))
  {
    theme = args[1].toLowerCase()
  }else{interaction.channel.send('К сожалению, тема не была найдена! Загрузка обычной карточки...')}
  }
}




if (args[1] == 'hentai' ) { 
  interaction.channel.send ('Сори, но иди ты!')
  theme = 'default'
  }


          console.log('456')

sharp.cache(false);
let image = sharp('./Background/' + theme + '/image.png');

if (fs.existsSync('./Background/' + theme + '/GIF'))
{
  image = sharp('./Background/' + theme + '/GIF/image.gif');
}


sharp(body)
.resize(171, 171)
.composite([

{ input: "./Images/testcircler3.png", top: 0, left: 0, blend: 'darken'},

])


.toBuffer()
            .then(function(body2) {


sharp(body2)
.composite([{ input: "./Images/testcircler3.png", top: 0, left: 0, blend: 'xor'},])
.toBuffer()
            .then(function(body3) {

//              
sharp.cache(false);
          

          if (theme !== 'glitch')
          {
          image
            .resize(1024, 1024)
            .composite([
              { input: './Images/NEWBG.png', top: 50, left: 50},
              { input: './tasks/activeBG.png', top: 275, left: 50},
              { input: './tasks/lastActiveBG.png', top: 275, left: 554},
              { input: './tasks/voice/default.png', top: 462, left: 50},

              { input: body3, top: 55, left: 55},

              { input: './tasks/bar.png', top: 345, left: 185},
              { input: './tasks/bar.png', top: 345, left: 689},
              { input: './tasks/bar.png', top: 532, left: 185},
              { input: activeImg, top: 286, left: 61}, //11outputBufferAct2
              { input: './tasks/lastActive/basic.png', top: 286, left: 565},
              { input: './tasks/voice/icon.png', top: 473, left: 60},
              { input: badgePath, top: 60, left: 800},
              { input: badge2Path, top: 166, left: 166},
              

              {input: outputBufferAct,  top: 345, left: 185},
              {input: outputBufferAct1,  top: 345, left: 689},
              {input: outputBufferAct2,  top: 532, left: 185},
              {input: './Images/emptybar.png',  top: 230, left: 132},
              {input: grandBuffer,  top: 230, left: 132},
              
              { input: out, top: 0, left: 0}])
            .toBuffer()
            .then(function(outputBuffer) {
              console.log("error: ", err)
              if (interaction.user != undefined)
              {
              interaction.editReply({files: [outputBuffer]}).catch(err => {});
              ctx.clearRect(0, 0, canvas.width, canvas.height)
              }else
              {
                interaction.channel.send({files: [outputBuffer]}).catch(err => {});;
              ctx.clearRect(0, 0, canvas.width, canvas.height)
              }
              // fs.unlinkSync(pingedUser + "temp.png")
              })
              .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });
          }else{
            image
            .composite([
              { input: './Images/Borders/5.png', top: 50, left: 50},
              { input: './tasks/activeBG.png', top: 666, left: 50},
              { input: body, top: 76, left: 76},
              { input: './tasks/bar.png', top: 345, left: 185},
              { input: activeImg, top: 286, left: 61}, //11
              { input: "./Images/circler.png", top: 76, left: 76},
              {input: outputBufferAct,  top: 345, left: 185},
              // {input: grandBuffer, top: 10, left: 10},
              { input: out, top: 0, left: 0}])
            .toBuffer()
            .then(function(outputBuffer) {
              console.log("error: ", err)
              msg.channel.send({files: [outputBuffer]});
              ctx.clearRect(0, 0, canvas.width, canvas.height)
              // fs.unlinkSync(pingedUser + "temp.png")
              })
              .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });
          }

          })
              .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });
  


          
          })
              .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });
              
        });      




        })
       
            })
 .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });

            })
            .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });
 })
 .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });

  })
  .catch(err => { interaction.channel.send('Сожалеем, но произошла ошибка при загрузке карточки!\nКод: ' + err) });




        },error => {interaction.channel.send('Хей! Что то пошло не так! Убедись, что ты указал верный ID или упомянул существующего пользователя!\nКод ошибки: ' + error)})
  }

   
  }
  
  }

module.exports = { cardCommand }